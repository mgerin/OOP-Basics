﻿namespace _08.RawData
{
    public class Tire
    {
        public double TirePressure { get; set; }
        public int TireAge { get; set; }
    }
}
